package com.jcg.hibernate.crud.operations;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class DbOperations {

	static Session sessionObj;
	static SessionFactory sessionFactoryObj;

	public final static Logger logger = Logger.getLogger(DbOperations.class);

	// This Method Is Used To Create The Hibernate's SessionFactory Object
	private static SessionFactory buildSessionFactory() {
		// Creating Configuration Instance & Passing Hibernate Configuration File
		Configuration configObj = new Configuration();
		configObj.configure("hibernate.cfg.xml");

		// Since Hibernate Version 4.x, ServiceRegistry Is Being Used
		ServiceRegistry serviceRegistryObj = new StandardServiceRegistryBuilder().applySettings(configObj.getProperties()).build(); 

		// Creating Hibernate SessionFactory Instance
		sessionFactoryObj = configObj.buildSessionFactory(serviceRegistryObj);
		return sessionFactoryObj;
	}
	
	public static void createStudent(studentName, rollNumber)
	try {
		// Getting Session Object From SessionFactory
		sessionObj = buildSessionFactory().openSession();
		// Getting Transaction Object From Session Object
		sessionObj.beginTransaction();

		// Creating Transaction student Entity 			
		}

		// Committing The Transactions To The Database
		sessionObj.getTransaction().commit();
		logger.info("\nSuccessfully Created '" + count + "' Records In The Database!\n");
	} catch(Exception sqlException) {
		if(null != sessionObj.getTransaction()) {
			logger.info("\n.......Transaction Is Being Rolled Back.......\n");
			sessionObj.getTransaction().rollback();
		}
		sqlException.printStackTrace();
	} finally {
		if(sessionObj != null) {
			sessionObj.close();
		}
	}
}

	public static void createStudentCourseEnrollmentRecord(studentCourseEnrollmentObj)
		int count = 0;
		Student studentObj = null;
		try {
			// Getting Session Object From SessionFactory
			sessionObj = buildSessionFactory().openSession();
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction();

			// Creating Transaction StudentCourseEnrollment Entities  			
			}

			// Committing The Transactions To The Database
			sessionObj.getTransaction().commit();
			logger.info("\nSuccessfully Created '" + count + "' Records In The Database!\n");
		} catch(Exception sqlException) {
			if(null != sessionObj.getTransaction()) {
				logger.info("\n.......Transaction Is Being Rolled Back.......\n");
				sessionObj.getTransaction().rollback();
			}
			sqlException.printStackTrace();
		} finally {
			if(sessionObj != null) {
				sessionObj.close();
			}
		}
	}

	@SuppressWarnings("unchecked")
	public static List<Student> displayStudnetRecords() {
		List<StudentCourseEnrollment> studentsList = new ArrayList<StudentCourseEnrollment>();		
		try {
			// Getting Session Object From SessionFactory
			sessionObj = buildSessionFactory().openSession();
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction();

			studentsList = sessionObj.createQuery("FROM StudentCourseEnrollment").list();
			Collections.sort(integers, new NameComparator());
		
		} catch(Exception sqlException) {
			if(null != sessionObj.getTransaction()) {
				logger.info("\n.......Transaction Is Being Rolled Back.......\n");
				sessionObj.getTransaction().rollback();
			}
			sqlException.printStackTrace();
		} finally {
			if(sessionObj != null) {
				sessionObj.close();
			}
		}
		return studentsList;
	}

	
	// Method 4(a): This Method Is Used To Delete A Particular Record From The Dat+
	public void deleteStudent(student_id){
		try {
			// Getting Session Object From SessionFactory
			sessionObj = buildSessionFactory().openSession();
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction();

			Student studObj = findRecordById(student_id);
			sessionObj.delete(studObj);

			// Committing The Transactions To The Database
			sessionObj.getTransaction().commit();
			logger.info("\nStudent With Id?= " + student_id + " Is Successfully Deleted From The Database!\n");
		} catch(Exception sqlException) {
			if(null != sessionObj.getTransaction()) {
				logger.info("\n.......Transaction Is Being Rolled Back.......\n");
				sessionObj.getTransaction().rollback();
			}
			sqlException.printStackTrace();
		} finally {
			if(sessionObj != null) {
				sessionObj.close();
			}
		}
	}

	public static void displayCourses(){		
		//get all courses to display from courses table
	}
}

class NameComparator implements Comparator<StudentCourseEnrollment> {
    @Override
    public int compare(StudentCourseEnrollment o1, StudentCourseEnrollment o2) {
        return o1.getStudnetName().compareTo(o2.getStudentName());
    }
}