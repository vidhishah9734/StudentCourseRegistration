package com.jcg.hibernate.crud.operations;

import org.apache.log4j.Logger;

import antlr.collections.List;

public class AppMain {

	public final static Logger logger = Logger.getLogger(AppMain.class);

	public static void main(String[] args) {
				
		DbOperations.displayCourses();
		
		getStudentInfoAndCreateStudent(){
			// get and set student info: studentName and rollNumber
			DbOperations.createStudent(String studentName, int rollNumber);
		}	
		
		getSelectedCourseAndCreateStudentCourseEnrollmentRecord() {
			
			// take input from student 
			//studentName, rollNumber, CourseName
			// set values on StudentCourseEnrollment Obj 
			DbOperations.createStudentCourseEnrollmentRecord(StudentCourseEnrollment studentCourseEnrollmentObj);
		}
		
		getStudentRollNumberAndDeleteStudentRecord(){
		// get student Roll number
		DbOperations.deleteRecord(studentId);
		}
			
		getCourseNameAndDisplayAllStudents(){
		// get course name
		List<StudentCourseEnrollment> displayAll = DbOperations.displayStudnetRecords(String CourseName);
		}	
		System.exit(0);
	} 
}