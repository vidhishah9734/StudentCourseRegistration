package com.jcg.hibernate.crud.operations;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student")
public class Courses {

	@Id
	@Column(name="course_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private final int courseId;
	
	@Column(name="course_name")
	private final String CourseName;
	
	getters and setters
	
	
	
}
