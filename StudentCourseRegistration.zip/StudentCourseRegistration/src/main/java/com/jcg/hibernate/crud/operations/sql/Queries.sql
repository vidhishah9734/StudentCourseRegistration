
CREATE TABLE IF NOT EXISTS student (
  student_id int(100) NOT NULL AUTO_INCREMENT,
  student_name varchar(50) DEFAULT NULL,
  roll_number varchar(50) DEFAULT NULL,
  course varchar(50) DEFAULT NULL,  
  PRIMARY KEY (student_id)
);

CREATE TABLE IF NOT EXISTS Course(
  course_id int(100) NOT NULL AUTO_INCREMENT,
  course_name varchar(50) DEFAULT NULL,  
  PRIMARY KEY (course_id)
);

likewise StudentCourseEnrollment table