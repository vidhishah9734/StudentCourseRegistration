package com.jcg.hibernate.crud.operations;

@Entity
@Table(name="StudentCourseEnrollment")
public class StudentCourseEnrollment {
	
	private final int enrollmentId;
	
	private final int courseId;
	
	private final int studentId;
	
	private final String courseName;
	
	private final String StudentName;
	
	private final Date courseEnrollmentTimeStamp;
	
	getters and setters;
		
}
